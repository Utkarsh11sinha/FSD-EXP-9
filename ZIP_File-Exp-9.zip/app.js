const steps = [
  "Copy the React source into a Node-based builder image.",
  "Install dependencies and run the production build command.",
  "Move the generated static assets into a small Nginx runtime image.",
  "Expose port 8080 and serve the build with compression and caching.",
  "Ship a lean runtime image without development dependencies."
];

const benefits = [
  {
    title: "Smaller Runtime",
    detail: "Only the compiled build and Nginx runtime move into production, helping keep the image compact."
  },
  {
    title: "Fast Static Delivery",
    detail: "Nginx serves the generated assets efficiently and keeps configuration focused on static hosting."
  },
  {
    title: "Better Performance",
    detail: "Gzip compression and cache headers reduce repeated downloads for JS, CSS, and media assets."
  },
  {
    title: "Cleaner CI/CD",
    detail: "The same Dockerfile can be reused in local development, pipelines, and cloud deployment workflows."
  }
];

document.getElementById("steps").innerHTML = steps
  .map((step) => `<li>${step}</li>`)
  .join("");

document.getElementById("benefits").innerHTML = benefits
  .map((benefit) => {
    return `
      <article class="benefit-item">
        <h3>${benefit.title}</h3>
        <p>${benefit.detail}</p>
      </article>
    `;
  })
  .join("");