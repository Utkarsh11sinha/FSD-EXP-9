# Experiment 09: Dockerize React Application with Multi-Stage Build

## Aim

Containerize a React application using Docker multi-stage builds for a production-ready deployment.

## Included Files

- `Dockerfile`: multi-stage build using Node and Nginx
- `nginx.conf`: gzip, caching headers, SPA fallback, and port `8080`
- `react-app/`: lightweight React source app prepared for container builds
- `index.html`, `styles.css`, `app.js`: deployable explanation and architecture demo

## Expected Outcome

- Production-ready image based on Alpine images
- Static assets served through Nginx on port `8080`
- Gzip compression and cache headers enabled