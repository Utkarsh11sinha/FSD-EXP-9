export default function App() {
  return (
    <main className="app">
      <section className="banner">
        <p className="eyebrow">Containerized React</p>
        <h1>Production Build Ready</h1>
        <p>
          This React app is designed to be built in Docker and served by Nginx as a static production site.
        </p>
      </section>

      <section className="cards">
        <article className="card">
          <h2>Build Stage</h2>
          <p>Uses Node to install dependencies and create optimized production assets.</p>
        </article>
        <article className="card">
          <h2>Runtime Stage</h2>
          <p>Uses Nginx Alpine to keep the runtime lightweight and focused on static delivery.</p>
        </article>
        <article className="card">
          <h2>Port 8080</h2>
          <p>Configured for production-style deployment with gzip and caching headers.</p>
        </article>
      </section>
    </main>
  );
}